-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 20, 2019 at 01:31 PM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iwt`
--
CREATE DATABASE IF NOT EXISTS `iwt` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `iwt`;

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
CREATE TABLE IF NOT EXISTS `items` (
  `i_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(80) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `img` varchar(80) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`i_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`i_id`, `title`, `quantity`, `price`, `img`, `date`) VALUES
(13, 'P30 Lite - Huawei', 20, 25000, 'images/item_images/P30.png', 1558341893),
(14, 'Iphone X 256GB - Apple', 10, 120000, 'images/item_images/X.jpg', 1558341928),
(15, 'Galaxy M20 - Samsung', 10, 40000, 'images/item_images/m20.jpg', 1558341965),
(16, 'Redmi Note 7 - Samsung', 10, 55000, 'images/item_images/note.jpg', 1558342005),
(17, 'iPhone 8 plus - Apple', 10, 130000, 'images/item_images/8.jpg', 1558342040),
(12, 'MI 8 pro 128GB - Xiaomi', 5, 45000, 'images/item_images/m.jpg', 1558341858);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `mail` varchar(70) NOT NULL,
  `address` varchar(240) NOT NULL,
  `password` varchar(128) NOT NULL,
  `role` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`mail`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `name`, `mail`, `address`, `password`, `role`) VALUES
(1, 'Sajith Athukorala', 'saji.athukorala@gmail.com', 'galle', '$2y$10$2hW54tliwfMlS.Pg9JL1zO4XEC8So.HU7Ka65V2ij5n17yZQTmMs.', 1),
(2, 'Kasun Athukorala', 'kasun@gmail.com', 'galleakmeemnagalleChoose...', '$2y$10$uNuaCrd7DHv0/vDINAzCgunUQa9l6y2chAgoANNQF9jDed9vGj14G', 1),
(3, 'prasad', 'pras@gmail.com', 'gallegalleNorth', '$2y$10$yzhkOv8Mf31SnO4g8c8Nn.hs7Uj/oBGXynVaOT5yYJf3ALeFD65Ei', 1),
(4, 'AdminPK', 'admin@gmail.com', 'North Galle', '$2y$10$EHRpoq5.FYm2sQf1iYBHXeuIbGKrzAjyXcMrrmnXhCmdKnhKlLLFS', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
